<title>E-Commerce</title>

<link rel="stylesheet" href="/assets/frontend/css/style.css">
<link rel="stylesheet" href="/assets/frontend/css/themify-icons.css">
<link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">

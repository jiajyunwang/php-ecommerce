    <?php
    include_once 'foot.php';
    ?>    
</body>
</html>
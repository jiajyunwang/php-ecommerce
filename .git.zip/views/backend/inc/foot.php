<script src="/assets/frontend/js/jquery-3.7.1.min.js"></script>
<script src="/assets/backend/js/demo.js"></script>
<script src="/assets/backend/js/display-image.js"></script>

<link rel="stylesheet" href="/assets/backend/css/admin-style.css">
<link rel="stylesheet" href="/assets/frontend/css/themify-icons.css">
<link rel="stylesheet" href="/assets/backend/css/editor.css">

<script src="https://cdn.ckeditor.com/ckeditor5/16.0.0/classic/ckeditor.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.4.0/jspdf.umd.min.js"></script>
<script src="https://html2canvas.hertzen.com/dist/html2canvas.min.js"></script>


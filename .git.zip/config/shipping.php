<?php

class Shipping {
    public const HOME_DELIVERY = 150;
}